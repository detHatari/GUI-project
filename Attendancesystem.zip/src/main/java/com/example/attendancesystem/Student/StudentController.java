package com.example.attendancesystem.Student;

import com.example.attendancesystem.LoginFormApp;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Stack;

public class StudentController {
//    @FXML
//    protected  void onBack(Event event) throws IOException {
//        Parent root = FXMLLoader.load(LoginFormApp.class.getResource("LoginView.fxml"));
//        Stage stage = (Stage) ( (Node)event.getSource()).getScene().getWindow();
//        Scene scene = new Scene(root);
//        stage.setTitle("Add Student Attendance");
//        stage.setWidth(stage.getWidth());
//        stage.setHeight(stage.getHeight());
//        stage.setScene(scene);
//
//        stage.show();
}
